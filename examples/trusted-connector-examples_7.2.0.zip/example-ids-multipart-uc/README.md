# IDSCP2 communication examples

This example demonstrates usage control between trusted connectors via the IDS Multipart protocol.

### Usage

First, start the server with the command `docker compose --profile server up`.

Second, start the client using the command `docker compose --profile client up`.