Example-009 demonstrates the connection between two REST services and the conversion of MQTT messages using the Trusted IoT Connector.

Documentation is located at https://fraunhofer-aisec.github.io/trusted-iot-connector-documentation/

(C)) Fraunhofer AISEC 2017
